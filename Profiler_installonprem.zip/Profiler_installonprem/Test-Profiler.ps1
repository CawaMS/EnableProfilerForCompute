﻿<#

.SYNOPSIS

Tests Profiler main entry point functionalities.


.DESCRIPTION

The main entry points are:
- Disable
- Uninstall
- Bootstrap (requires InstrumentationKey argument)

They can be supplied individually or not.
If more than one is supplied, then they are executed in the same order above.


.PARAMETER InstrumentationKey


Only used if in bootstrap mode.
Configures Profiler to use this instrumentation key.


.PARAMETER Disable

Disable all running Profiler related processes.


.PARAMETER Uninstall

Uninstall existing Profiler installations.


.PARAMETER Bootstrap

Requires the instrumentation key argument.
Downloads and extracts the Profiler archive,
then proceeds to configure, install and enable it.

If successful, then it keeps running forever or until a Disable action is called or an error is encoutered.


.EXAMPLE

Test-Profile.ps1 -Bootstrap -InstrumentationKey "some application insights guid"


.EXAMPLE 

Test-Profile.ps1 -Disable


.EXAMPLE 

Test-Profile.ps1 -Uninstall


.NOTES

You need to run this as administrator.


#>
Param(
    [string] $InstrumentationKey,
    [switch] $Disable,
    [switch] $Uninstall,
    [switch] $Bootstrap
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"


$ProfilerDataDirectoryPath = [IO.Path]::Combine([System.Environment]::GetEnvironmentVariable("ProgramData"), "ApplicationInsightsProfiler")
$ProfilerArchiveDirectoryPath = [IO.Path]::Combine($ProfilerDataDirectoryPath, "Profiler")
$ProfilerHandlerExePath = [IO.Path]::Combine($ProfilerArchiveDirectoryPath, "Tools", "ApplicationInsightsProfiler-Handler.exe")


if ($Disable) {
    . $ProfilerHandlerExePath --disable
}

if ($Uninstall) {
    . $ProfilerHandlerExePath --uninstall
}

if ($Bootstrap) {
    if ([String]::IsNullOrWhiteSpace($InstrumentationKey)) {
        throw [ArgumentException]::new("An instrumentation key is required to bootstrap Profiler.")
    }

    $ArchivePath = [IO.Path]::Combine($PSScriptRoot, "Profiler.zip")
    if (-not [IO.File]::Exists($ArchivePath)) {
        throw "Missing Profiler.zip archive file in this script directory."
    }

    [IO.Directory]::CreateDirectory($ProfilerDataDirectoryPath) | Out-Null

    Expand-Archive $ArchivePath -DestinationPath $ProfilerArchiveDirectoryPath -Force

    # Prepare configuration string for Profiler bootstrap
    $EscapedLogsDirectoryPath = [IO.Directory]::CreateDirectory([IO.Path]::Combine($ProfilerDataDirectoryPath, "Logs")).FullName.Replace("\", "\\")
    [IO.File]::WriteAllText([IO.Path]::Combine($ProfilerDataDirectoryPath, "Config.json"),
        "{ ""Args"": [""--ikey"",""$InstrumentationKey"", ""-m"", ""Default""], ""LogFolder"": ""$EscapedLogsDirectoryPath"" }")

    . $ProfilerHandlerExePath --bootstrap
}